SUCCESS = 1
PROCESS = 2
ERROR = 3
WARNING = 4

GREEN = 1
RED = 2
YELLOW = 3
BLUE = 4
WHITE = 5

DUMMY_RAND = "aaaabbbbccccddddeeeeffffgggghhhh"
DUMMY_SRES = "aaaabbbb"
DUMMY_IMSI = "4600000000000000"







